package com.kdlc.framework.http.volley;

import android.content.Context;
import android.widget.ImageView;

import com.kdlc.framework.http.ConvertUtil;
import com.kdlc.framework.http.HttpError;
import com.kdlc.framework.http.bean.RequestBean;
import com.kdlc.framework.http.interfaces.HttpInterface;
import com.kdlc.framework.http.interfaces.HttpResultInterface;
import com.kdlc.framework.http.volley.Request.Method;
import com.kdlc.framework.http.volley.toolbox.HttpStack;
import com.kdlc.framework.http.volley.toolbox.StringRequest;
import com.kdlc.framework.http.volley.toolbox.Volley;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.OkHttpClient;

public class VolleyHttp implements HttpInterface {


    RequestQueue mQueue;

    public VolleyHttp(Context context) {
//		mQueue = Volley.newRequestQueue(context, new OkHttpStack(null,(SSLSocketFactory)SSLSocketFactory.getDefault()));
//		mQueue = Volley.newRequestQueue(context, new HurlStack(null,(SSLSocketFactory)SSLSocketFactory.getDefault()));
//		mQueue = Volley.newRequestQueue(context,new OkHttpStack());  
//		mQueue = Volley.newRequestQueue(context);
        mQueue = Volley.newRequestQueue(context, getHttpStack());


    }

    /***********
     * 获取httpStack
     *
     * @return
     */
    private HttpStack getHttpStack() {
        // okhttp 3.0以后的版本构建OkHttpClient使用Builder
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        try {

            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, new TrustManager[]{
                    new X509TrustManager() {

                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            // TODO Auto-generated method stub
                            return new X509Certificate[]{};
                        }

                        @Override
                        public void checkServerTrusted(X509Certificate[] chain, String authType)
                                throws CertificateException {
                            // TODO Auto-generated method stub

                        }

                        @Override
                        public void checkClientTrusted(X509Certificate[] chain, String authType)
                                throws CertificateException {
                            // TODO Auto-generated method stub

                        }
                    }

            }, new SecureRandom());
            builder.sslSocketFactory(sc.getSocketFactory());
            builder.hostnameVerifier(new HostnameVerifier() {

                @Override
                public boolean verify(String hostname, SSLSession session) {
                    // TODO Auto-generated method stub
                    return true;
                }
            });

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return new OkHttp3Stack(builder.build());
    }


    public RequestQueue getRequestQueue() {
        return mQueue;
    }

    /**************
     * 获取Cache
     */
    private String getCache(String url) {
        String cache = "";
        if (mQueue.getCache().get(url) != null) {
            cache = new String(mQueue.getCache().get(url).data);
        }
        return cache;

    }


    /*********************
     * String post请求
     */
    @Override
    public void onPostHttp(final String url, final RequestBean request, final HttpResultInterface callBack) {
        // TODO Auto-generated method stub

        Object tag = request.getTag();

        StringRequest stringRequest = new StringRequest(Method.POST, url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                // TODO Auto-generated method stub

                onRequestSuccess(response, callBack);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                onRequestError(error, callBack, url);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                // TODO Auto-generated method stub

                //cookie设置

                Map<String, String> headers = VolleyHttp.this.getHeaders(request);
//				if(headers==null)
//					headers = new HashMap<String, String>();
//				headers.put("Charset", "UTF-8");
////				headers.put("Content-Type", "application/x-javascript");
//				headers.put("Accept-Encoding", "gzip,deflate");
                if (headers == null || headers.size() == 0)
                    headers = super.getHeaders();
                return headers;
//				return super.getHeaders();
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // TODO Auto-generated method stub

                HashMap<String, String> params = request.getParams();
                if (params == null)
                    params = ConvertUtil.getMyParams(request);
                return params;
            }

        };

        //删除相同请求并重新设置
        if (tag != null) {
            mQueue.cancelAll(tag);
            stringRequest.setTag(tag);
        }


        //延时 超时 策略
        if (request.getRetryPolicy() != null)
            stringRequest.setRetryPolicy(request.getRetryPolicy());
        stringRequest.setShouldCache(request.isSetCache());

        mQueue.add(stringRequest);
    }

    /*****************
     * String get 请求
     */
    @Override
    public void onGetHttp(String url, final RequestBean request, final HttpResultInterface callBack) {
        // TODO Auto-generated method stub

        Object tag = request.getTag();


        HashMap<String, String> map = request.getParams();
        if (map == null)
            map = ConvertUtil.getMyParams(request);
        Iterator iter = map.entrySet().iterator();
        String serviceUrl = "";
        while (iter.hasNext()) {

            Map.Entry entry = (Map.Entry) iter.next();
            String key = (String) entry.getKey();
            String val = (String) entry.getValue();
            try {

                if ("".equals(serviceUrl))
                    serviceUrl = serviceUrl + key + "=" + URLEncoder.encode(val, "utf-8");
                else
                    serviceUrl = serviceUrl + "&" + key + "=" + URLEncoder.encode(val, "utf-8");
            } catch (UnsupportedEncodingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }
        if (serviceUrl.length() > 0) {
            if (url.contains("?")) {
                url = url + "&" + serviceUrl;
            } else {
                url = url + "?" + serviceUrl;
            }
        }

        final String getUrl = url;
        StringRequest stringRequest = new StringRequest(Method.GET, getUrl, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                onRequestSuccess(response, callBack);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {


                onRequestError(error, callBack, getUrl);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                // TODO Auto-generated method stub

                //cookie设置

                Map<String, String> headers = VolleyHttp.this.getHeaders(request);
//				if(headers==null)
//					headers = new HashMap<String, String>();
//				headers.put("Charset", "UTF-8");
////				headers.put("Content-Type", "application/x-javascript");
//				headers.put("Accept-Encoding", "gzip,deflate");
                if (headers == null || headers.size() == 0)
                    headers = super.getHeaders();
                return headers;
//				return super.getHeaders();

            }

//			@Override
//			protected Map<String, String> getParams() throws AuthFailureError {
//				// TODO Auto-generated method stub
//				
//				HashMap<String,String> params = request.getParams();
//				if(params==null)
//					params = ConvertUtil.getMyParams(request);
//				return params;
//			}

        };

//		//删除相同请求并重新设置
//		if(tag!=null)
//		{
//			mQueue.cancelAll(tag);
//			stringRequest.setTag(tag);
//		}

        //延时 超时 策略
        if (request.getRetryPolicy() != null)
            stringRequest.setRetryPolicy(request.getRetryPolicy());
        stringRequest.setShouldCache(request.isSetCache());
        mQueue.add(stringRequest);
    }

    @Override
    public void onPutHttp(String url, RequestBean requet, HttpResultInterface callBack) {
        // TODO
    }

    @Override
    public void onPatchHttp(String url, RequestBean requet, HttpResultInterface callBack) {
        // TODO
    }

    @Override
    public void onDeleteHttp(String url, RequestBean requet, HttpResultInterface callBack) {
        // TODO
    }

    @Override
    public void onHeadHttp(String url, RequestBean requet, HttpResultInterface callBack) {
        // TODO
    }


    /*********
     * 成功请求
     *
     * @param result
     * @param callBack
     */
    private void onRequestSuccess(String result, HttpResultInterface callBack) {
        if (callBack != null)
            callBack.onSuccess(result);
    }

    /******
     * 失败处理
     *
     * @param error
     * @param callBack
     */
    private void onRequestError(VolleyError error, HttpResultInterface callBack, String getUrl) {
        HttpError httpError = new HttpError();
        if (error instanceof ServerError) {//服务器内部错误

            httpError.setErrCode(HttpError.HTTP_ERROR_SERVER);
            httpError.setErrMessage(HttpError.HTTP_ERROR_SERVER_MSG);

        } else if (error instanceof NoConnectionError) {//连接错误

            httpError.setErrCode(HttpError.HTTP_ERROR_CONNECT);
            httpError.setErrMessage(HttpError.HTTP_ERROR_CONNECT_MSG);
        } else if (error instanceof TimeoutError) {
            httpError.setErrCode(HttpError.HTTP_ERROR_TIMEOUT);
            httpError.setErrMessage(HttpError.HTTP_ERROR_TIMEOUT_MSG);

        } else {
            httpError.setErrCode(HttpError.HTTP_ERROR_REQUEST);
            httpError.setErrMessage(HttpError.HTTP_ERROR_REQUEST_MSG);
        }


        httpError.setCache(getCache(getUrl));
        if (callBack != null) {
            if (error.getMessage() != null && error.getMessage().trim().length() > 0)
                httpError.setDetailMessage(error.getMessage());
            callBack.onFailed(httpError);
        }
    }

    /**********
     * 获取cookie
     *
     * @param request
     * @return
     */
    private Map<String, String> getHeaders(RequestBean request) {

        return request.getCookie();
    }

    /**********
     * 暂不使用
     */
    @Override
    public void onLoadImage(String url, ImageView imageView) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onCancelRequest(Object tag) {
        // TODO Auto-generated method stub
        if (mQueue != null && tag != null)
            mQueue.cancelAll(tag);
    }


}
