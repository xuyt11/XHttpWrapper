package com.kdlc.framework.http.retrofit;

import android.content.Context;

import com.kdlc.framework.http.interfaces.HttpPolicy;
import com.kdlc.framework.http.interfaces.HttpResultInterface;
import com.kdlc.framework.http.retrofit.converter.StringConverterFactory;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by wuyan on 16/11/24.
 */
public class RetrofitPolicy implements HttpPolicy<String> {


    private String BASE_PATH="http://192.168.8.147:1024/";

    private Retrofit mRetrofit;

    private static final long DEFAULT_TIMEOUT = 5000;//默认超时时间(毫秒)

    private RetrofitHttpService mRetrofitHttpService;

    public RetrofitPolicy(){
        OkHttpClient.Builder okHttpClient = new OkHttpClient.Builder();

        okHttpClient.connectTimeout(DEFAULT_TIMEOUT, TimeUnit.MILLISECONDS);
        mRetrofit = new Retrofit.Builder()
                .client(okHttpClient.build())
                .addConverterFactory(StringConverterFactory.create())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .baseUrl(BASE_PATH)
                .build();
        mRetrofitHttpService = mRetrofit.create(RetrofitHttpService.class);

    }

    private static volatile RetrofitPolicy mInstance;
    private Context mAppliactionContext;
    private static String mVersionApi;

    //构造函数私有，不允许外部调用
    private RetrofitPolicy(Context mAppliactionContext, String mVersionApi) {
        mRetrofitHttpService = mRetrofit.create(RetrofitHttpService.class);
        this.mAppliactionContext = mAppliactionContext;
        this.mVersionApi = mVersionApi;
    }

    @Override
    public HttpPolicy getPolicy() {

        return null;
    }

    @Override
    public void onPostHttp(String url, Map<String, String> params, final HttpResultInterface callBack) {
        mRetrofitHttpService.Obpost(url,null)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<String>() {
            @Override
            public void onCompleted() {

            }

            @Override
            public void onError(Throwable e) {
                callBack.onFailed(null);
            }

            @Override
            public void onNext(String s) {
                callBack.onSuccess(s);
            }
        });
    }

    @Override
    public void onGetHttp(String url, Map<String, String> params,final HttpResultInterface callBack) {
        mRetrofitHttpService.Obget(url,params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<String>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {

                        callBack.onFailed(null);
                    }

                    @Override
                    public void onNext(String s) {

                        callBack.onSuccess(s);
                    }
                });
    }

    @Override
    public void onCancelRequest(Object tag) {

    }



}
