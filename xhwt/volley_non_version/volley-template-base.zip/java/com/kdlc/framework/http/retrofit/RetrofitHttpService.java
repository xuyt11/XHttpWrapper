package com.kdlc.framework.http.retrofit;

import java.util.Map;

import retrofit2.Call;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.QueryMap;
import retrofit2.http.Url;
import rx.Observable;

/**
 * retrofit的接口书写模式 绝对是优秀的。很彻底的解偶
 * <p/>
 * 但是对于一个小公司
 * <p/>
 * 写一个接口 改N个文件是不适合的，是耍流氓
 * <p/>
 * 这里作出2个共通的模式
 */

public interface RetrofitHttpService {

    @GET()
    Call<String> get(@Url String url, @QueryMap Map<String, String> params);

    @FormUrlEncoded
    @POST()
    Call<String> post(@Url String url, @FieldMap Map<String, String> params);

    @GET()
    Observable<String> Obget(@Url String url, @QueryMap Map<String, String> params);

    @FormUrlEncoded
    @POST()
    Observable<String> Obpost(@Url String url, @FieldMap Map<String, String> params);

}
