package com.kdlc.framework.http.retrofit.converter;

import java.io.IOException;
import java.net.URLDecoder;

import okhttp3.ResponseBody;
import retrofit2.Converter;


public class StringResponseBodyConverter implements Converter<ResponseBody, String> {
    @Override
    public String convert(ResponseBody value) throws IOException {
        try {
            return URLDecoder.decode(value.string()) ;
        } finally {
            value.close();
        }
    }
}
