package com.kdlc.framework.http;

import android.content.Context;

import com.kdlc.framework.http.bean.RequestBean;
import com.kdlc.framework.http.interfaces.HttpInterface;
import com.kdlc.framework.http.interfaces.HttpResultInterface;
import com.kdlc.framework.http.volley.RequestQueue;
import com.kdlc.framework.http.volley.VolleyHttp;

public class HttpProxy {

    private static volatile HttpProxy httpProxy;
    private static HttpInterface httpService;

    /*********
     * 服务请求代理类
     */
    private HttpProxy() {
    }

    /**********
     * double check获取单例
     *
     * @return
     */
    public static HttpProxy getInstance(Context context) {
        if (httpProxy == null) {
            synchronized (HttpProxy.class) {
                if (httpProxy == null)
                    httpProxy = new HttpProxy();
                loadServiceInStance(context);
            }
        }

        return httpProxy;
    }

    /***********
     * 装载请求实例
     */
    private static void loadServiceInStance(Context context) {
        if (httpService == null)
            httpService = new VolleyHttp(context);
    }

    /*****
     * 发送post请求
     */
    public void onPostRequest(String url, RequestBean requset, HttpResultInterface callBack) {
        httpService.onPostHttp(url, requset, callBack);
    }

    /*******
     * get请求
     *
     * @param url
     * @param requset
     * @param callBack
     */
    public void onGetRequest(String url, RequestBean requset, HttpResultInterface callBack) {
        httpService.onGetHttp(url, requset, callBack);
    }

    public void onPutRequest(String url, RequestBean requet, HttpResultInterface callBack) {
        httpService.onPutHttp(url, requet, callBack);
    }

    public void onPatchRequest(String url, RequestBean requet, HttpResultInterface callBack) {
        httpService.onPatchHttp(url, requet, callBack);
    }

    public void onDeleteRequest(String url, RequestBean requet, HttpResultInterface callBack) {
        httpService.onDeleteHttp(url, requet, callBack);
    }

    public void onHeadRequest(String url, RequestBean requet, HttpResultInterface callBack) {
        httpService.onHeadHttp(url, requet, callBack);
    }

    /********
     * 取消请求
     *
     * @param tag
     */
    public void cancelRequest(Object tag) {
        httpService.onCancelRequest(tag);
    }


    /******
     * 动态注入服务请求
     *
     * @param proxy
     */
    public void setHttpProxy(HttpInterface proxy) {
        httpService = proxy;
    }

    /*********
     * 兼容两套结构单独做的处理 后期要删除
     *
     * @return
     */
    public RequestQueue getRequestQueue() {
        if (httpService instanceof VolleyHttp)
            return ((VolleyHttp) httpService).getRequestQueue();

        return null;
    }

}
