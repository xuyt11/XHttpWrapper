package com.kdlc.framework.http.bean;

public class ResultBean {

	
}
