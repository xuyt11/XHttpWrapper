package com.kdlc.framework.http.bean;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.kdlc.framework.http.volley.RetryPolicy;

public abstract class RequestBean {

	//获取类名称
	private String bean_class_name;
	
	public RequestBean()
	{
		bean_class_name = this.getClass().getName();
	}
	
	
	public String getClassName()
	{
		return bean_class_name;
	}
	public   abstract Object getTag(); //获取Volley请求标签
	public   abstract Map<String,String> getCookie();//获取请求cookie
	public   abstract RetryPolicy getRetryPolicy();//获取延时策略
	public   abstract boolean isSetCache();//是否设置缓存
	public   abstract HashMap<String,String> getParams();//获取
	
}
