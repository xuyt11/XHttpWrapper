package com.kdlc.framework.http;

import android.content.Context;

import com.kdlc.framework.http.interfaces.HttpPolicy;
import com.kdlc.framework.http.interfaces.HttpResultInterface;
import com.kdlc.framework.http.retrofit.RetrofitPolicy;

import java.util.Map;

/**
 * Created by wuyan on 16/11/24.
 *
 * 基础的api请求管理
 * 1.提供默认的实例 方便调用者 进行快速的开发
 * 2.提供自定义的入口 方便调用者 做更多可适应配置
 * TODO 是不是要做成策略模式 还在考虑
 *
 */
public class ApiManager {

    public static ApiManager mInstance;

    public void setPolicy(HttpPolicy policy) {
        this.policy = policy;
    }

    private HttpPolicy policy;

    public ApiManager(Context context){
        policy = new RetrofitPolicy();
    }

    public static ApiManager getInstance(Context ctx){
        if(mInstance ==null){
            synchronized (ApiManager.class){
                if(mInstance == null){
                    mInstance = new ApiManager(ctx);
                    return mInstance;
                }
            }
        }
        return mInstance;
    }


    public void onPostHttp(String url, Map<String, String> params, HttpResultInterface callBack) {
        policy.onPostHttp(url,params,callBack);
    }

    public void onGetHttp(String url, Map<String, String> params, HttpResultInterface callBack){
        policy.onGetHttp(url,params,callBack);
    }

}
