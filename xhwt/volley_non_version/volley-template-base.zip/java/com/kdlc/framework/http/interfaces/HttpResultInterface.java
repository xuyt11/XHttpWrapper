package com.kdlc.framework.http.interfaces;

import com.kdlc.framework.http.HttpError;

public interface HttpResultInterface<T> {
	public void onSuccess(String result);//请求 成功
	public void onFailed(HttpError rror);//请求失败
}
