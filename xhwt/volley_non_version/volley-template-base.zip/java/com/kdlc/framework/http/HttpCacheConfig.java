package com.kdlc.framework.http;

public class HttpCacheConfig {

	private boolean isCache = false;//是否要设置缓存
}
