package com.kdlc.framework.http.interfaces;

import java.util.Map;

public interface HttpPolicy<T>{


	public HttpPolicy getPolicy();

	/*****
	 * postRequest请求
	 */
	public void onPostHttp(String url, Map<String, String> params, HttpResultInterface callBack);
	/*********
	 * getRequest请求
	 */
	public void onGetHttp(String url, Map<String, String> params, HttpResultInterface callBack);
	
	/***********
	 * 取消请求
	 * @param tag
	 */
	public void onCancelRequest(Object tag);
	

}
