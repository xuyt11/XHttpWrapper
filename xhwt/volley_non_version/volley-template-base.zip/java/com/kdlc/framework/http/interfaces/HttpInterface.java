package com.kdlc.framework.http.interfaces;


import com.kdlc.framework.http.bean.RequestBean;

import android.widget.ImageView;

public interface HttpInterface {

    void onPostHttp(String url, RequestBean requet, HttpResultInterface callBack);

    void onGetHttp(String url, RequestBean requet, HttpResultInterface callBack);

    void onPutHttp(String url, RequestBean requet, HttpResultInterface callBack);

    void onPatchHttp(String url, RequestBean requet, HttpResultInterface callBack);

    void onDeleteHttp(String url, RequestBean requet, HttpResultInterface callBack);

    void onHeadHttp(String url, RequestBean requet, HttpResultInterface callBack);

    /***********
     * 取消请求
     *
     * @param tag
     */
    void onCancelRequest(Object tag);

    /*********
     * 下载网络请求
     *
     * @param url
     * @param imageView
     */
    void onLoadImage(String url, ImageView imageView);

}
