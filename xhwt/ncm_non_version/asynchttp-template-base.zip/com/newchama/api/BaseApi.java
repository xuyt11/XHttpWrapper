package com.newchama.api;

import android.content.Context;

import com.loopj.android.http.RequestHandle;
import com.loopj.android.http.ResponseHandlerInterface;
import com.newchama.tool.net.NetRequest;
import com.newchama.tool.net.NetWorker;
import com.newchama.tool.util.JsonUtil;

import java.lang.reflect.Type;

public class BaseApi {

    public static final String BaseUrl = "http://test.newchama.com";
//    public static final String BaseUrl = "http://172.16.2.211:8080/";
    //    public static final String BaseUrl = "http://172.16.0.174:8000"; //jay
    public static final String Authorization = "Authorization";

    public static String getFullUrl(String url) {
        return getFullUrl(BaseUrl, url);
    }

    /**
     * 获取到全路径的地址
     */
    public static String getFullUrl(String homePage, String url) {
        if (isUrl(url)) {
            return url;
        }

        boolean hasSeparator1 = homePage.endsWith("/");
        boolean hasSeparator2 = url.startsWith("/");

        if ((hasSeparator1 && !hasSeparator2) || (!hasSeparator1 && hasSeparator2)) {// 其中一个有/符号
            return homePage + url;
        }

        if (!hasSeparator1 && !hasSeparator2) {// 两个都没有/符号
            return homePage + "/" + url;
        }

        // 两个都有/符号
        return homePage + url.substring(1);
    }

    public static boolean isUrl(String url) {
        if (null == url || url.trim().length() <= 0) {
            return false;
        }

        if (url.startsWith("http://") || url.startsWith("https://")) {
            return true;
        }

        return false;
    }


    public static <T> T getResponseObject(byte[] responseBody, Type dataType) {
        return JsonUtil.toObject(new String(responseBody), dataType);
    }

    public static void cancelRequestHandle(RequestHandle requestHandle) {
        if (requestHandle == null) {
            return;
        }

        if (requestHandle.isCancelled() || requestHandle.isFinished()) {
            return;
        }

        requestHandle.cancel(true);
    }

    public static void cancelRequestHandles(RequestHandle... requestHandles) {
        if (requestHandles == null || requestHandles.length <= 0) {
            return;
        }

        for (RequestHandle requesthandle : requestHandles) {
            cancelRequestHandle(requesthandle);
        }
    }

    public static void cancelRequests(Context context) {
        NetWorker.cancelRequests(context);
    }

    public static void setToken2HttpHeader() {
        String token = "";// TODO 
        NetWorker.addHeader(BaseApi.Authorization, "Token " + token);
    }


    public static RequestHandle getThisUrlData(Context cxt001, String url, ResponseHandlerInterface response) {
        NetRequest request = new NetRequest();
        request.setMethod(NetRequest.Method.GET);

        request.setUrl(url);

        return NetWorker.execute(cxt001, request, response);
    }

}
