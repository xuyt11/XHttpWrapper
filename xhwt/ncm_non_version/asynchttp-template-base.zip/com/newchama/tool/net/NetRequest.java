package com.newchama.tool.net;

import com.loopj.android.http.RequestParams;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by anlin on 16/2/19.
 */
public class NetRequest {

    public enum Method {
        GET(1), POST(2), PUT(3), DELETE(4), PATCH(5), HEAD(6), POST_TEXT(7), PATCH_TEXT(8);
        public int value;

        Method(int val) {
            this.value = val;
        }
    }

    private String url;
    private RequestParams params;
    private HashMap<String, String> headers;
    private String contentType;
    private Method method;
    private Map<String, Object> paramMap;

    public NetRequest() {
        params = new RequestParams();
        method = Method.POST;
        paramMap = new HashMap<>();
    }

    public NetRequest(String url) {
        this.url = url;
        method = Method.GET;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public void addParam(String key, String value) {
        if (method == Method.POST || method == Method.PATCH) {
            paramMap.put(key, value);
        }
        params.put(key, value);
    }

    public void addParam(String key, int value) {
        if (method == Method.POST || method == Method.PATCH) {
            paramMap.put(key, value);
        }
        params.put(key, value);
    }

    public void addParam(String key, Object object) {
        if (method == Method.POST || method == Method.PATCH) {
            paramMap.put(key, object);
        }
        params.put(key, object);
    }

    public void addParam(String key, File file) {
        if (method == Method.POST || method == Method.PATCH) {
            paramMap.put(key, file);
        }
        try {
            params.put(key, file, null, file.getName());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void addHeader(String key, String value) {
        if (headers == null) {
            headers = new HashMap<>();
        }
        headers.put(key, value);
    }

    public String getContentType() {
        return contentType;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }

    public RequestParams getParams() {
        return params;
    }

    public String getUrl() {
        return url;
    }

    public Method getMethod() {
        return method;
    }

    public void setMethod(Method method) {
        this.method = method;
        if (method == Method.POST || method == Method.PATCH) {
            contentType = "application/json";
        }
    }

    public Map<String, Object> getParamMap() {
        return paramMap;
    }
}
