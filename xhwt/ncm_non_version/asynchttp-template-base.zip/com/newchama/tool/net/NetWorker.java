package com.newchama.tool.net;

import android.content.Context;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.RequestHandle;
import com.loopj.android.http.ResponseHandlerInterface;
import com.newchama.tool.util.JsonUtil;

import java.io.UnsupportedEncodingException;
import java.util.Map;
import java.util.Set;

import cz.msebera.android.httpclient.entity.ByteArrayEntity;
import cz.msebera.android.httpclient.message.BasicHeader;
import cz.msebera.android.httpclient.protocol.HTTP;

/**
 * Created by zal on 16/3/18.
 */
public class NetWorker {

    private static AsyncHttpClient client;

    /**
     * 创建NetWorker
     */
    public static void createWorker() {
        client = new AsyncHttpClient();
        client.setTimeout(10000);
        addHeader("Accept", "application/json; version=2.0");
    }

    /**
     * 执行HTTP请求
     *
     * @param context
     * @param netRequest
     * @param response
     */
    public static RequestHandle execute(Context context, NetRequest netRequest, ResponseHandlerInterface response) {
        client.removeHeader(HTTP.CONTENT_TYPE);
        Map<String, String> headers = netRequest.getHeaders();
        if (headers != null && !headers.isEmpty()) {
            for (String key : headers.keySet()) {
                client.addHeader(key, headers.get(key));
            }
        }
        RequestHandle requestHandle = null;
        switch (netRequest.getMethod()) {
            case GET:
                requestHandle = client.get(context, netRequest.getUrl(), null, netRequest.getParams(), response);
                break;
            case POST_TEXT:
                requestHandle = client.post(context, netRequest.getUrl(), null, netRequest.getParams(), netRequest.getContentType(), response);
                break;
            case POST:
                try {
                    ByteArrayEntity byteArrayEntity = new ByteArrayEntity(JsonUtil.toJson(netRequest.getParamMap()).getBytes("utf-8"));
                    byteArrayEntity.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, netRequest.getContentType()));
                    requestHandle = client.post(context, netRequest.getUrl(), byteArrayEntity, netRequest.getContentType(), response);
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                break;
            case PUT:
                requestHandle = client.put(context, netRequest.getUrl(), netRequest.getParams(), response);
                break;
            case PATCH_TEXT:
                requestHandle = client.patch(context, netRequest.getUrl(), netRequest.getParams(), response);
                break;
            case PATCH:
                try {
                    ByteArrayEntity byteArrayEntity = new ByteArrayEntity(JsonUtil.toJson(netRequest.getParamMap()).getBytes("utf-8"));
                    byteArrayEntity.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, netRequest.getContentType()));
                    requestHandle = client.patch(context, netRequest.getUrl(), byteArrayEntity, netRequest.getContentType(), response);
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                break;
            case DELETE:
                requestHandle = client.delete(context, netRequest.getUrl(), null, netRequest.getParams(), response);
                break;
            case HEAD:
                requestHandle = client.head(context, netRequest.getUrl(), netRequest.getParams(), response);
        }
        return requestHandle;
    }

    public static void addHeader(String key, String value) {
        client.addHeader(key, value);
    }

    public static void clearHeader() {
        client.removeAllHeaders();
    }

    public static void removeHeader(Set<String> set) {
        if (set != null && set.size() > 0) {
            for (String key : set) {
                removeHeader(key);
            }
        }
    }

    public static void removeHeader(String key) {
        client.removeHeader(key);
    }


    public static void cancelRequests(Context context) {
        client.cancelRequests(context, true);
    }
}
